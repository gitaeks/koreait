# NotoSans-subset

NotoSansCJKkr(bold, light, medium, regular)을 경량화한 한글 웹폰트입니다. 경량화한 방법은 [한글 웹 폰트 경량화해 사용하기](http://blog.coderifleman.com/post/111825720099)를 참고해주세요.

[NotoSans](https://www.google.com/get/noto/#/)는 Google과 어도비가 합작해 개발한 웹폰트입니다. 라이센스는 [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0.html) 입니다.
